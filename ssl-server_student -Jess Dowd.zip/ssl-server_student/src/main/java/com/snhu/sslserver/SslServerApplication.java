package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ChecksumController {

    // Route to return the checksum
	@GetMapping("/hash")
	public String getChecksum() {
	    try {
	        String data = "Jess Dowd Artemis Financial Verification";
	        MessageDigest digest = MessageDigest.getInstance("SHA-256");
	        byte[] hash = digest.digest(data.getBytes("UTF-8"));
	        StringBuilder hexString = new StringBuilder();

	        for (byte b : hash) {
	            String hex = Integer.toHexString(0xff & b);
	            if (hex.length() == 1) hexString.append('0');
	            hexString.append(hex);
	        }

	        return "Data: " + data + "\nChecksum: " + hexString.toString();
	    } catch (Exception e) {
	        return "Error generating checksum: " + e.getMessage();
	    }
	}

}